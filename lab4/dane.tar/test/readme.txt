zadania 1-2:
test_same_osoby

zadania 3-5:
test_rodzice

zadania 6-8:
test_dzieci_rodzice
